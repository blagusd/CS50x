#include <stdio.h>
#include <cs50.h>

int main(void) {
    
    long n;
    do {
        n = get_long("Number: \n");
    }
}