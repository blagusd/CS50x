#include <stdio.h>
#include <cs50.h>

int main(void) {

    int x = 0;
    do {
        x = get_int("Height: ");
    } while (x < 1 || x > 8);

    char c = '#';

    if (x == 1) {
        printf("%c  %c\n", c, c);
    } else {
       for (int i = 0; i < x; i++) {
           for (int j = 0; j < (x + 3 + i); j++) {
               if (j < x-i-1 || j == x || j == x+1) {
                   printf("%c", ' ');
               } else {
                   printf("%c", c);
               }
           }
           printf("\n");
       }
   }

}